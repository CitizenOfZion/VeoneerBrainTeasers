#include "pch.h"
#define CPP

#ifdef CPP

#include <algorithm>
#include <iostream>
#include <string>

void comb(std::string inpStr, int K)
{
	int N = inpStr.length();
	std::string bitmask(K, 1); // K leading 1's
	bitmask.resize(N, 0); // N-K trailing 0's

	// print integers and permute bitmask
	do {
		for (int i = 0; i <= N; ++i) // [0..N-1] integers
		{
			if (bitmask[i]) std::cout << " " << inpStr[i];
		}
		std::cout << '\n';
	} while (std::prev_permutation(bitmask.begin(), bitmask.end()));
}

int main()
{
	std::cout << "Enter a string of alphabets more than 1 and less than 23\n";
	std::string inpStr;
	std::cin >> inpStr;
	int len = inpStr.length();
	if (len < 2 || len > 22)
	{
		std::cout << "String length not acceptable\n";
	}
	else
	{
		for (int i = 1; i <= len; i++)
			comb(inpStr, i);
	}
}
#else //Pure C

#include <stdio.h> 
#include <stdlib.h> 
void DoCombos(char arr[], char data[], int start, int end,
	int index, int r);

void printCombos(char arr[], int n, int r)
{	
	char* data = (char *)malloc(n * sizeof(char));	
	DoCombos(arr, data, 0, n - 1, 0, r);
}

void DoCombos(char arr[], char data[], int start, int end,
	int index, int r)
{	
	if (index == r)
	{
		for (int j = 0; j < r; j++)
			printf("%c ", data[j]);
		printf("\n");
		return;
	}
	
	for (int i = start; i <= end && end - i + 1 >= r - index; i++)
	{
		data[index] = arr[i];
		DoCombos(arr, data, i + 1, end, index + 1, r);
	}
}

void my_strlen(const char *str, size_t *len)
{
	for (*len = 0; str[*len]; (*len)++);
}

// Driver program to test above functions 
int main()
{
	char inpStr[23] = { 0 };
	//	char inpStr[23] = "abcdefghij";
	size_t len;
	printf("Enter a string of alphabets more than 1 and less than 23\n");
	
	scanf("%s\n", inpStr);
	my_strlen(inpStr, &len);
	printf("%d\n", len);
	return 0;

	//int len = 5;
	if (len < 2 || len > 22)
	{
		printf("String length not acceptable\n");
	}
	else
	{
		for (int i = 1; i <= len; i++)
			printCombos(inpStr, len, i);
	}
}

#endif // CPP
