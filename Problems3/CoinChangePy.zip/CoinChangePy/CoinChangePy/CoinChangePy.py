import time


CoinsArray = [1, 2, 5];
InputArray = [4, 10];

def ChangeCombinations(goal, coins):
    denominations = [[coin] for coin in coins]

    new_denominations = []
    combinations = []

    while denominations:
        for denomination in denominations:
            s = sum(denomination)
            for coin in coins:
                if coin >= denomination[-1]:
                    if s + coin < goal:
                        new_denominations.append(denomination + [coin])
                    elif s + coin == goal:
                        combinations.append(denomination + [coin])
        denominations = new_denominations
        new_denominations = []
    for combo in combinations:
        print(combo)

if __name__ == "__main__":  
    start = time.time()
    for input in InputArray:
        print("Change combinations for Amount:", input)
        ChangeCombinations(input, CoinsArray);
    end = time.time()

    print("\nTime taken in Milliseconds:", (end - start) * 1000 )   
